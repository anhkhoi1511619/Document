package com.example.log.impl.constant;

public enum MachineError {
		CONTROLLERM("EC-M", 0, 1),
		CONTROLLERS1("EC-Sub1", 1, 1),
		CONTROLLERS2("EC-Sub2", 1, 2),
		CONTROLLERS3("EC-Sub3", 1, 3),
		READER1("ER-1", 2, 1),
		READER2("ER-2", 2, 2),
		READER3("ER-3", 2, 3),
		READER4("ER-4", 2, 4),
		READER5("ER-5", 2, 5),
		READER6("ER-6", 2, 6),
		READER7("ER-7", 2, 7),
		READER8("ER-8", 2, 8),
		READER9("ER-9", 2, 9),
		READER10("ER-10", 2, 10),
		READER11("ER-11", 2, 11),
		READER12("ER-12", 2, 12),
		READER13("ER-13", 2, 13),
		READER14("ER-14", 2, 14),
		READER15("ER-15", 2, 15),
		READER16("ER-16", 2, 16),
		READER1OK("ER-1 OK", 21, 1),
		READER2OK("ER-2 OK", 21, 2),
		READER3OK("ER-3 OK", 21, 3),
		READER4OK("ER-4 OK", 21, 4),
		READER5OK("ER-5 OK", 21, 5),
		READER6OK("ER-6 OK", 21, 6),
		READER7OK("ER-7 OK", 21, 7),
		READER8OK("ER-8 OK", 21, 8),
		READER9OK("ER-9 OK", 21, 9),
		READER10OK("ER-10 OK", 21, 10),
		READER11OK("ER-11 OK", 21, 11),
		READER12OK("ER-12 OK", 21, 12),
		READER13OK("ER-13 OK", 21, 13),
		READER14OK("ER-14 OK", 21, 14),
		READER15OK("ER-15 OK", 21, 15),
		READER16OK("ER-16 OK", 21, 16),
		SUBBOARD("ES-Subboard", 3, 1),
		FROZEN("EF-UIFrozen", 4, 1),
		MAXR_READER_THREAD("ER-MaxThread", 5, 1),
		STARTUP("ES-Startup", 6, 1);
    public static MachineError find(int v, int id) {
        for (MachineError x : values()) if (x.key == v && x.id == id) return x;
        return values()[0];
    }
    MachineError (String name, int key, int id)
	{
		this.name = name;
		this.key = key;
		this.id = id;
	}
	
	public String name;
	public int key;
	public int id;
}
