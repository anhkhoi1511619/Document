public class NativeResource {
    long nativePtr;

    public NativeResource() {
        nativePtr = NativeLibrary.allocate();
        System.out.println("🟢 NativeResource created with nativePtr = " + nativePtr);
        NativeResourceCleaner.register(this, nativePtr);
    }
}
