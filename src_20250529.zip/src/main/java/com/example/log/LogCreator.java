package com.example.log;
import com.example.log.impl.*;
import com.example.data.StationError;
import java.util.List;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.regex.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class LogCreator {
    List<StationError> list;
    public LogCreator(String path)
    {
        list = new ArrayList();
        run(path, list);
    }
    public void run(String path, List<StationError> list)
    {
        Pattern pattern = Pattern.compile("setStopSequence\\(\\d+\\)");
        //String updateKeyword = "Task UpdateProcedure is starting";
        String updateKeyword = "LAQRA,\"App is starting...\"";


        List<String> currentLines = new ArrayList<>();
        boolean insideBlock = false;
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(path))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Matcher matcher = pattern.matcher(line);

                if (matcher.find() || line.contains(updateKeyword)) {
                    // Nếu đang trong block thì in ra block cũ và reset
                    if (insideBlock && !currentLines.isEmpty()) {
                        String block = String.join("\n", currentLines);
                        System.out.println("🟩 Một block mới:\n" + block + "\n");
                        StationError se = new StationError();
                        LogProcedure procedure = new LogProcedure(block, se);
                        procedure.run();
                        list.add(se);
                        currentLines.clear(); // reset lại cho block tiếp theo
                    }

                    insideBlock = true; // bắt đầu block mới
                }

                if (insideBlock) {
                    currentLines.add(line);
                }
            }

            // Đừng quên in block cuối cùng
            if (!currentLines.isEmpty()) {
                String lastBlock = String.join("\n", currentLines);
                System.out.println("🟥 Block cuối:\n" + lastBlock);
                StationError se = new StationError();
                LogProcedure procedure = new LogProcedure(lastBlock, se);
                procedure.run();
                list.add(se);
            }

        } catch (IOException e) {
            System.err.println("Lỗi khi đọc file: " + e.getMessage());
        }
    }
    public List<StationError> create() {
                  return list;
    }
}
