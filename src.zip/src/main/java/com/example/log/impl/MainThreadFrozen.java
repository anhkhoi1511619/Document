package com.example.log.impl;
import com.example.log.impl.constant.MachineError;

import com.example.data.*;
import java.util.regex.*;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.Arrays;

public class MainThreadFrozen extends Jobs {

    public MainThreadFrozen(String line, StationError se) {
        super(line, se);
    }
    @Override
    protected void doRun() {
		if (line.contains("UIHealthWatcher")){
			this.se.setErrorName(addErrorNameOnce(this.se.getErrorName(), MachineError.FROZEN.name));
		}
		setStatus(Status.DONE);
    }
}
