package com.example.update.impl;
import com.example.data.AppFrameData;
import com.example.data.ControllerInfo;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;


public class UpdateProcedure extends UpdateJobs {
    CheckUpdateFolder checkUpdateFolder;
    EmptyUpdateFolder emptyUpdateFolder;
    MoveToUpdateFolder movetoUpdateFolder;
    ModifyUpdateFolder modifyUpdateFolder;
    List<Consumer<AppFrameData>> onFinishedUI = new ArrayList<>();

    AppFrameData appFrameData;
    public UpdateProcedure(String line) {
        super(line);
        checkUpdateFolder = new CheckUpdateFolder(line);
        emptyUpdateFolder = new EmptyUpdateFolder(line);
        movetoUpdateFolder = new MoveToUpdateFolder(line);
        modifyUpdateFolder = new ModifyUpdateFolder(line);
        checkUpdateFolder
            .chain(emptyUpdateFolder, ChainCondition.RUN_IF_SUCCESS)
            .chain(movetoUpdateFolder, ChainCondition.RUN_IF_SUCCESS)
            .chain(modifyUpdateFolder, ChainCondition.RUN_ALWAYS)
            .then(this::report);
    }
    void report() {
        setStatus(Status.DONE);
        for (var callback: onFinishedUI) {
            this.appFrameData.setTrainNames(checkUpdateFolder.getTrainNames());
            this.appFrameData.setControllerInfoMap(movetoUpdateFolder.getControllerInfo());
            callback.accept(appFrameData);
        }
    }
    public void updateRunButton(AppFrameData appFrameData, Consumer<AppFrameData> callback) {
        this.appFrameData = appFrameData;
        this.onFinishedUI.add(callback);
    }
    @Override
    protected void doRun() {
        checkUpdateFolder.run();
    }
}