package com.example.log.impl;
import com.example.data.*;

public class LogProcedure extends Jobs {
    StationInfo stationInfo;
    ControllerError controllerError;
    ReaderError readerError;
    SubboardError subboardError;
    StartupInfo startupInfo;
    QRICInfo qricInfo;
    Jobs softwareError;
    MainThreadFrozen frozen;
    MaxReaderThread maxReaderThread;
    AutoStartupError autoStartupError;

    public LogProcedure(String line, StationError se) {
        super(line, se);
        stationInfo = new StationInfo(line, se);
        controllerError = new ControllerError(line, se);
        readerError = new ReaderError(line, se);
        subboardError = new SubboardError(line, se);
        startupInfo = new StartupInfo(line, se);
        qricInfo = new QRICInfo(line, se);
        frozen = new MainThreadFrozen(line, se);
        maxReaderThread = new MaxReaderThread(line, se);
        autoStartupError = new AutoStartupError(line, se);
        // Chain the jobs together
        softwareError = Jobs.runAll(
                controllerError,
                readerError,
                subboardError);
        startupInfo
            .chain(stationInfo, ChainCondition.RUN_IF_FAILED)
            .chain(softwareError, ChainCondition.RUN_ALWAYS)
            //.chain(startupInfo, ChainCondition.RUN_ALWAYS)
            .chain(qricInfo, ChainCondition.RUN_ALWAYS)
            .chain(frozen, ChainCondition.RUN_ALWAYS)
            .chain(maxReaderThread, ChainCondition.RUN_ALWAYS)
            .chain(autoStartupError, ChainCondition.RUN_ALWAYS)
            .then(this::report);        
    }

    void report() {
        setStatus(Status.DONE);
    }
    @Override
    protected void doRun() {
        startupInfo.run();
    }
}
