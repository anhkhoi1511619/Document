package com.example.log.impl;
import com.example.log.impl.constant.MachineError;


import com.example.data.*;
import java.util.regex.*;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.Arrays;



public class ControllerError extends Jobs {
    static boolean isMainControllerError = false;
    public ControllerError(String line, StationError se) {
        super(line, se);
    }

    @Override
    protected void doRun() {
        isMainControllerError = line.contains("Sub-board is received  停留所送り or 停留所戻し with StationNumber");
        String keyword = "Server is waiting for handshaking";
        int count = line.split(Pattern.quote(keyword), -1).length - 1;
        System.out.println("Số lần xuất hiện \"" + keyword + "\": " + count);

        if (count > 0) {
            MachineError me = MachineError.CONTROLLERM;

            String[] lines = line.split("\n");
            Pattern pattern = Pattern.compile("Server is waiting for handshaking with client at port (\\d+)");

            for (String value : lines) {
                if (value.contains("Server is waiting for handshaking with client at port")) {
                    System.out.println(value);
                    Matcher matcher = pattern.matcher(value);
                    if (matcher.find()) {
                        String portStr = matcher.group(1); // ví dụ: 52104
                        int port = Integer.parseInt(portStr);
                        int controllerNo = port - 52101; // 52102 → 1, 52103 → 2, v.v.

                        System.out.println(line);
                        System.out.println("---> Lỗi tại controller " + controllerNo);
                        if(isMainControllerError)me = MachineError.find(1, controllerNo);
                        //if(isMainControllerError && me == MachineError.CONTROLLERM) continue;
                        this.se.setErrorName(addErrorNameOnce(this.se.getErrorName(), me.name));
                    }
                }
            }
        }
         this.se.setErrorCount(this.se.getErrorCount() + count);
        setStatus(Status.DONE);
    }
    

}
