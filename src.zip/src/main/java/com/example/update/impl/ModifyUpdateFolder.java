package com.example.update.impl;

public class ModifyUpdateFolder extends UpdateJobs {
    public ModifyUpdateFolder(String line) {
        super(line);
    }
    @Override
    protected void doRun() {
        setStatus(Status.DONE);
    }
}