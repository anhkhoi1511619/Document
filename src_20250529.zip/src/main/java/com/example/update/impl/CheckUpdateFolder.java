package com.example.update.impl;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CheckUpdateFolder extends UpdateJobs {
    List<String> trainNames = new ArrayList<>();
    public CheckUpdateFolder(String line) {
        super(line);
    }
    @Override
    protected void doRun() {
        System.out.println("Checking: "+line);
        setStatus(checkFolder(line));
    }
    public List<String> getTrainNames() {
        return trainNames;
    }

    Status checkFolder(String inputPathTarGz) {
        //unzipFile .tar.gz
        //TarGz格納パス、解凍後のcsvログファイルの格納パスを定義
        String sourcePath = inputPathTarGz;
        //全てのTarGzipファイルを取得
        File folderTarGzip = new File(sourcePath);
        File [] listOfFilesTargz = folderTarGzip.listFiles();
        if(listOfFilesTargz!=null){
            for (int i=0; i<listOfFilesTargz.length;i++){
                    System.out.println("Folder : "+listOfFilesTargz[i].getName());
                    trainNames.add(listOfFilesTargz[i].getName());
            }
            return Status.DONE;
        } else {
            System.out.println("No files found in the directory: " + sourcePath);
            return Status.FAILED;
        }
    }
}