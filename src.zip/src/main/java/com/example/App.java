package com.example;
import com.example.utils.SharedUtils;
import com.example.data.StationError;
import com.example.base.AppFrame;
import com.example.data.AppFrameData;
import com.example.data.ControllerInfo;
import com.example.log.LogCreator;
import com.example.update.impl.*;

import javax.swing.*;
import java.util.List;
import java.util.ArrayList;
import com.example.data.ControllerInfo;

import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Set;
import java.util.*;

public class App {
    public static void main(String[] args) throws Exception {
      System.err.println("Check Error Tool");
      SwingUtilities.invokeLater(() -> {
        AppFrameData appFrameData = new AppFrameData();
	      AppFrame f = new AppFrame(appFrameData);
        UpdateProcedure updateProcedure = new UpdateProcedure("\\\\lecip_dc2\\LCP\\H-▼LCP品質保証本部\\H 【LCP品証 各部データ受渡専用】\\202505\\広島電鉄\\20250422_広電電車_582_1156（対策ソフトの先行展開結果確認）");
        updateProcedure.run();
        updateProcedure.updateRunButton(appFrameData, (data) -> {
                  SharedUtils.updateTimeUI(f, appFrameData, data);
              });
        f.setRunEvent((actionEvent) -> {
                SharedUtils.updateTableUI(updateProcedure, f, appFrameData);
            });
      });
    }

}
