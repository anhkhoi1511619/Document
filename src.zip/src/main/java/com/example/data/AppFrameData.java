package com.example.data;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.*;
public class AppFrameData {
    public List<String> trainNames = new ArrayList<>();
    public String chooseTrainName = "";
    public String date = "";
    public String trainType = "";
    Map<String, Set<ControllerInfo>> controllerInfoMap = new HashMap<>();
    public Map<String, Set<ControllerInfo>> getControllerInfoMap() {
        return controllerInfoMap;
    }
    public void setControllerInfoMap(Map<String, Set<ControllerInfo>> controllerInfoMap) {
        this.controllerInfoMap = controllerInfoMap;
    }
    public String getTrainType() {
        return trainType;
    }   
    public void setTrainType(String trainType) {
        this.trainType = trainType;
    }
    public String getChooseTrainName() {
        return chooseTrainName;
    }
    public void setChooseTrainName(String chooseTrainName) {
        this.chooseTrainName = chooseTrainName;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public List<String> getTrainNames() {
        return trainNames;
    }
    public void setTrainNames(List<String> trainNames) {
        this.trainNames = trainNames;
    }
    public String print() {
        StringBuilder ret = new StringBuilder();
        for (var field : this.getClass().getFields()) {
            try {
                var val = field.get(this);
                var valStr = val != null ? val.toString() : "null";
                ret.append(field.getName()).append(": ").append(valStr).append(",");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return ret.toString();
    }
}
