package com.example.log.impl;
import com.example.log.impl.constant.MachineError;


import com.example.data.*;
import java.util.regex.*;

import com.example.data.*;
import java.util.regex.*;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.Arrays;

public class ReaderErrorStart extends Jobs {
    public ReaderErrorStart(String line, StationError se) {
        super(line, se);
    }
    @Override
    protected void doRun() {
        String keyword = "Preparing openned";

        // Cách 1: dùng split để đếm số lần xuất hiện
        int count = line.split(Pattern.quote(keyword), -1).length - 1;

        System.out.println("Số lần xuất hiện \"" + keyword + "\": " + count);
        if (count > 0) {
            MachineError me = MachineError.READER1;
            String[] lines = line.split("\\R"); // hoặc .split("\n")
            Pattern pattern = Pattern.compile("Preparing openned 192\\.168\\.254\\.4(\\d)");

            for (String l : lines) {
                Matcher matcher = pattern.matcher(l);
                if (matcher.find()) {
                    String ipStr = matcher.group(1);     // ví dụ: "5"
                    int ip = Integer.parseInt(ipStr);    // 5
                    int readerNo = ip - 4;                   // Nếu bạn cần subtract, dùng ip - 4

                    System.out.println(l);
                    System.out.println("---> Lỗi tại reader " + readerNo);
                    me = MachineError.find(2, readerNo);
                    this.se.setErrorName(addErrorNameOnce(this.se.getErrorName(), me.name));
                }
            }
            this.se.setErrorCount(this.se.getErrorCount() + count);
        }
        setStatus(Status.DONE);
    }
    public String addErrorNameOnce(String current, String newError) {
        Set<String> set = new LinkedHashSet<>();
        if (current != null && !current.isEmpty()) {
            set.addAll(Arrays.asList(current.split(",\\s*")));
        }
        set.add(newError);
        return String.join(", ", set);
    }
}
