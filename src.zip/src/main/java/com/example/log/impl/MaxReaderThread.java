package com.example.log.impl;
import com.example.data.*;
import com.example.log.impl.constant.MachineError;


import com.example.data.*;
import java.util.regex.*;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.Arrays;
public class MaxReaderThread extends Jobs {
    public MaxReaderThread(String line, StationError se) {
        super(line, se);
    }
    @Override
    protected void doRun() {
		if (line.contains("connection pool is half way full 26, drop this package")){
			this.se.setErrorName(addErrorNameOnce(this.se.getErrorName(), MachineError.MAXR_READER_THREAD.name));
		}
		setStatus(Status.DONE);
    }
    public String addErrorNameOnce(String current, String newError) {
        Set<String> set = new LinkedHashSet<>();
        if (current != null && !current.isEmpty()) {
            set.addAll(Arrays.asList(current.split(",\\s*")));
        }
        set.add(newError);
        return String.join(", ", set);
    }
}
