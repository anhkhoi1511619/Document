﻿// See https://aka.ms/new-console-template for more information
using System;
using Lecip.Net;
using System.Threading;

namespace HelloWorld
{
    class Program
    {
        //private static TcpIF tcp;

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            TcpIF tcp = new TcpIF();
            open(tcp);
            while (true)
            {
                Console.WriteLine("Press any key to send data, or 'q' to quit...");

                send(tcp);
                Thread.Sleep(200); // Dừng 1000 milliseconds = 1 giây
                // close();

            }
        }
        private static void open(TcpIF tcp)
        {
            if (tcp.IsOpen) return;
            tcp.SendIpAddr = "192.168.105.123";
            tcp.RecvIpAddr = "192.168.105.104";
            tcp.SendPortNo = 51003;
            tcp.RecvPortNo = 52013;

            tcp.Open();
            tcp.RcvManager("192.168.105.104", 51004);
            Console.WriteLine("TCP connection opened.");
        }

        // private static void close()
        // {
        //     if(!this.tcp.IsOpen) return;
        //     this.tcp.Close();
        // }

        private static void send(TcpIF tcp)
        {
            byte[] s = { 0x01, 0x02, 0xFF }; // Gán trực tiếp giá trị hex
            tcp.Send(s, s.Length);
        }
  }
}
