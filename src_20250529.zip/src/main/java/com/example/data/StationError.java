package com.example.data;

public class StationError {
    private String stationName;     // 駅
    private String arrivalTime;     // 到着時刻
    private int    stationID;  
    private String errorName = ""; 
    private int    errorCount;
    private String errorDetail;
    private String errorReason;
    
    public StationError () {}

    public StationError(String stationName, String arrivalTime, int stationID, String errorName, int errorCount, String errorDetail, String errorReason) {
        this.stationName = stationName;
        this.arrivalTime = arrivalTime;
        this.stationID   = stationID;
        this.errorName   = errorName;
        this.errorCount  = errorCount;
        this.errorDetail = errorDetail;
        this.errorReason = errorReason;
    }
    
    public String getStationName()
    {
        return this.stationName;
    }
    public String getArrivalTime()
    {
        return this.arrivalTime;
    }
    public int getStationID()
    {
        return this.stationID;
    }
    public String getErrorName()
    {
        return this.errorName;
    }
    public int getErrorCount()
    {
        return this.errorCount;
    }
    public String getErrorDetail()
    {
        return this.errorDetail;
    }
    public String getErrorReason()
    {
        return this.errorReason;
    }

    public void setStationName(String value)
    {
        this.stationName = value;
    }
    public void setArrivalTime(String value)
    {
        this.arrivalTime = value;
    }
    public void setStationID(int value)
    {
        this.stationID = value;
    }
    public void setErrorName(String value)
    {
        this.errorName = value;
    }
    public void setErrorCount(int value)
    {
        this.errorCount = value;
    }
    public void setErrorDetail(String value)
    {
        this.errorDetail = value;
    }
    public void setErrorReason(String value)
    {
        this.errorReason = value;
    }
    

    public Object[] toTableRow() {
        return new Object[]{
            stationName,
            arrivalTime,
            stationID,
            errorName,
            errorCount,
            errorDetail,
            errorReason
        };
    }
}
