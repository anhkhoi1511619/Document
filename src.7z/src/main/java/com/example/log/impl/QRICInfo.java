package com.example.log.impl;
import com.example.data.*;

public class QRICInfo extends Jobs {

    public QRICInfo(String line, StationError se) {
        super(line, se);
    }
    @Override
    protected void doRun() {
        setStatus(Status.DONE);
    }
}
