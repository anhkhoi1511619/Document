import java.lang.ref.*;
import java.util.concurrent.*;

public class NativeResourceCleaner {
    private static final ReferenceQueue<NativeResource> refQueue = new ReferenceQueue<>();
    private static final ConcurrentHashMap<PhantomReference<NativeResource>, Long> nativePtrs = new ConcurrentHashMap<>();

    static {
        // Start cleaner thread
        Thread cleaner = new Thread(() -> {
            while (true) {
                try {
                    PhantomReference<NativeResource> ref = (PhantomReference<NativeResource>) refQueue.remove();
                    long ptr = nativePtrs.remove(ref);
                    NativeLibrary.free(ptr);
                    System.out.println("🧹 Freed nativePtr = " + ptr);
                } catch (InterruptedException e) {
                    break;
                }
            }
        });
        cleaner.setDaemon(true);
        cleaner.start();
    }

    public static void register(NativeResource obj, long ptr) {
        PhantomReference<NativeResource> ref = new PhantomReference<>(obj, refQueue);
        nativePtrs.put(ref, ptr);
    }
}
