package com.example.log.impl;
import com.example.data.*;
import java.util.regex.*;

public class StartupInfo extends Jobs {
    public StartupInfo(String line, StationError se) {
        super(line, se);
    }
    @Override
    protected void doRun() {
        // Cách 1: tách theo dòng
        String[] lines = line.split("\n"); // \\R: tương thích mọi hệ newline (\n, \r\n)
        if (lines.length > 0) {
            String firstLine = lines[0];
            System.out.println("Dòng đầu tiên:");
            System.out.println(firstLine);
            if (!firstLine.contains("App is starting..."))
            {
                setStatus(Status.FAILED);
                return;
            }
            // Regex để lấy 3 nhóm: số, số, tên
            // Biểu thức chính quy để bắt 3 nhóm
            Pattern pattern = Pattern.compile(
                "(\\d{2}:\\d{2}:\\d{2}\\.\\d+),LAQRA"
            );
            Matcher matcher = pattern.matcher(firstLine);

            if (matcher.find()) {
                String time = matcher.group(1);            // 06:27:03.879

                System.out.println("Time: " + time);
                this.se.setArrivalTime(time);
                this.se.setStationName("アプリ起動");
                setStatus(Status.DONE);
                return;
            } else {
                System.out.println("Không khớp định dạng chuỗi.");
            }
        } else {
            System.out.println("no found");
        }
        setStatus(Status.FAILED);
    }
}
