public class NativeLibrary {
    static {
        System.loadLibrary("nativelib"); // libnativelib.so / nativelib.dll
    }

    public static native long allocate();
    public static native void free(long ptr);
}
