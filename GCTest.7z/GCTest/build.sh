#!/bin/bash

set -e  # nếu có lỗi thì dừng lại ngay

echo "📦 1. Compiling Java source files..."
javac NativeLibrary.java NativeResource.java NativeResourceCleaner.java Main.java

echo "🔧 2. Generating JNI header file from NativeLibrary.java..."
# Với JDK >= 8: dùng javac -h
javac -h . NativeLibrary.java

# Nếu bạn dùng JDK 8 trở xuống, dùng: javah -jni NativeLibrary

echo "⚙️ 3. Compiling NativeLibrary.c into a native library..."
gcc -shared -fPIC -o libnativelib.so \
  -I${JAVA_HOME}/include \
  -I${JAVA_HOME}/include/linux \
  NativeLibrary.c

echo "✅ Build successful!"
