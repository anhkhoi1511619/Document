package com.example.log.impl;
import com.example.data.*;

public class AutoStartupError extends Jobs {
    public AutoStartupError(String line, StationError se) {
        super(line, se);
    }
    @Override
    protected void doRun() {
		if (line.contains("Task UpdateProcedure is starting") &&
               !line.contains("LAQRA,\"App is starting...\"")){
			this.se.setErrorDetail("意図せずアプリ再起動");
		}
        setStatus(Status.DONE);
    }
}
