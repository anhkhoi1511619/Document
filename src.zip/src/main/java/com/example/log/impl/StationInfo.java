package com.example.log.impl;
import com.example.data.*;
import java.util.regex.*;

public class StationInfo extends Jobs {
    public StationInfo(String line, StationError se) {
        super(line, se);
    }
    @Override
    protected void doRun() {
        // Cách 1: tách theo dòng
        String[] lines = line.split("\n"); // \\R: tương thích mọi hệ newline (\n, \r\n)
        if (lines.length > 0) {
            String firstLine = lines[0];
            System.out.println("Dòng đầu tiên:");
            System.out.println(firstLine);
            // Regex để lấy 3 nhóm: số, số, tên
            // Biểu thức chính quy để bắt 3 nhóm
            Pattern pattern = Pattern.compile(
                "(\\d{2}:\\d{2}:\\d{2}\\.\\d+),ROUTE_DATA.*?setStopSequence\\((\\d+)\\).*?ticket number: (\\d+) sequence name: \\[[^\\]]+\\]([^\\s]+)"
            );
            Pattern pattern2 = Pattern.compile("系統番号[:「]\\s*(\\d+)[」]?");
            Matcher matcher = pattern.matcher(firstLine);
            Matcher matcher2 = pattern2.matcher(firstLine);

            if (matcher.find()) {
                String time = matcher.group(1);            // 06:27:03.879
                String stopSequence = matcher.group(2);  // 2
                int ticketNumber = Integer.parseInt(matcher.group(3));  // 18
                String sequenceName = matcher.group(4);    // 高須

                System.out.println("Time: " + time);
                System.out.println("Stop Sequence: " + stopSequence);
                System.out.println("Ticket Number: " + ticketNumber);
                System.out.println("Sequence Name: " + sequenceName);
                this.se.setArrivalTime(time);
                this.se.setStationName(sequenceName);
                this.se.setStationID(stopSequence);
            } else if (matcher2.find()) {
                String stationID = matcher2.group(1); // Lấy số hệ thống
                System.out.println("受信系統番号：" + stationID);
                this.se.setStationID("受信系統： "+stationID);
                // Tách phần trước dấu phẩy
                String[] parts = firstLine.split(",");
                String[] datetime = parts[0].split(" ");  // ["2025-05-28", "15:57:29.717"]

                String time = datetime[1];
                System.out.println("Time: " + time); // → 15:57:29.717
                this.se.setArrivalTime(time);
            }
            else {
                System.out.println("Không khớp định dạng chuỗi.");
            }
        } else {
            System.out.println("no found");
        }
        setStatus(Status.DONE);
    }
    
}
