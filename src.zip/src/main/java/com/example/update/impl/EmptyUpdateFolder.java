package com.example.update.impl;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

public class EmptyUpdateFolder extends UpdateJobs {
    public EmptyUpdateFolder(String line) {
        super(line);
    }
    @Override
    protected void doRun() {

        Path dirPath = Paths.get("input"); // đường dẫn tương đối đến thư mục input

        try {
            // XÓA nếu tồn tại
            if (Files.exists(dirPath)) {
                Files.walkFileTree(dirPath, new SimpleFileVisitor<>() {
                    @Override
                    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                        Files.delete(file);
                        return FileVisitResult.CONTINUE;
                    }

                    @Override
                    public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                        Files.delete(dir);
                        return FileVisitResult.CONTINUE;
                    }
                });
            }

            // TẠO lại thư mục
            Files.createDirectories(dirPath);
            System.out.println("Empty and create: " + dirPath.toAbsolutePath());
            setStatus(Status.DONE);
        } catch (IOException e) {
            e.printStackTrace();
            setStatus(Status.FAILED);
        }
    }
}