package com.example.log.impl;
import com.example.log.impl.constant.MachineError;


import com.example.data.*;
import java.util.regex.*;

import com.example.data.*;
import java.util.regex.*;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.Arrays;

public class ReaderError extends Jobs {
    ReaderErrorStart readerErrorStart;
    ReaderErrorEnd readerErrorEnd;
    public ReaderError(String line, StationError se) {
        super(line, se);
        this.readerErrorStart = new ReaderErrorStart(line, se);
        this.readerErrorEnd = new ReaderErrorEnd(line, se);
        readerErrorStart
            .chain(readerErrorEnd, ChainCondition.RUN_ALWAYS)
            .then(this::report);
    }
    void report() {
        setStatus(Status.DONE);
    }
    @Override
    protected void doRun() {
        readerErrorStart.run();
    }
}
