package com.example.log.impl;
import com.example.data.*;

public class SubboardError extends Jobs {
    public SubboardError(String line, StationError se) {
        super(line, se);
    }
    @Override
    protected void doRun() {
        setStatus(Status.DONE);
    }
}
