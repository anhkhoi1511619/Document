package com.example.utils;
import com.example.data.StationError;
import com.example.base.AppFrame;
import com.example.data.AppFrameData;
import com.example.data.ControllerInfo;
import com.example.log.LogCreator;
import com.example.update.impl.*;

import javax.swing.*;
import java.util.List;
import java.util.ArrayList;
import com.example.data.ControllerInfo;

import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Set;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
public class SharedUtils {
    public static List<String> getTimeList(Map<String, Set<ControllerInfo>> controllerInfoMap,String trainName, String date, String id)
    {
        List<String> list = new ArrayList();
        if(controllerInfoMap == null) return list;
                      for (Map.Entry<String, Set<ControllerInfo>> entry : controllerInfoMap.entrySet()) {
                          String trainNameStr = entry.getKey();
                          if(!trainNameStr.equals(trainName)) continue;
                          Set<ControllerInfo> dataSet = entry.getValue();
                          System.out.println("Train Name: " + trainNameStr);
                          for (ControllerInfo data1 : dataSet) {
                              System.out.println(data1.print());
                              if (data1.getControllerRaw().equals(id) && 
                                    data1.getDate().equals(date))
                              {
                                    list.add(data1.getTime());
                              }
                          }
                      }
                      return list;
    }
    public static String createFileName(Map<String, Set<ControllerInfo>> controllerInfoMap,String trainName, String time, String date, String id)
    {
        if (trainName == null || trainName.isEmpty() || time == null || time.isEmpty() || date == null || date.isEmpty() || id == null || id.isEmpty()) {
            System.err.println("Invalid parameters provided for creating file name.");
            return "";
        }
        System.out.println("Train Name: " + trainName);
        System.out.println("time: " + time.substring(0, 4));
        System.out.println("date: " + date);
        System.out.println("Train id: " + id);

        final String pathSource = "input";
        final String pathParent = "log";
        final String fileName = "operation_log.csv";
        if(controllerInfoMap == null) return "";
                                    for (Map.Entry<String, Set<ControllerInfo>> entry : controllerInfoMap.entrySet()) {
                                        String trainNameStr = entry.getKey();
                                        if(!trainNameStr.equals(trainName)) continue;
                                        Set<ControllerInfo> dataSet = entry.getValue();
                                        System.out.println("Train Name: " + trainNameStr);
                                        for (ControllerInfo data1 : dataSet) {
                                            System.out.println(data1.print());
                                            System.out.println("time check: " + data1.getTime().substring(0, 4));
                                            System.out.println("date check: " + data1.getDate());
                                            System.out.println("Train id check: " + data1.getControllerRaw());
                                            if (data1.getControllerRaw().equals(id) && 
                                                    data1.getDate().equals(date) 
                                                    //&& data1.getTime().substring(0, 4).equals(time.substring(0, 4))
                                                    ){
                                                    try {
                                                        LocalTime inputTime = LocalTime.parse(time, DateTimeFormatter.ofPattern("HHmmss"));
                                                        LocalTime dataTime = LocalTime.parse(data1.getTime(), DateTimeFormatter.ofPattern("HHmmss"));

                                                        long diffMinutes = ChronoUnit.MINUTES.between(dataTime, inputTime);

                                                        int trainNumber = 0;
                                                        try {                                                           
                                                            if (Math.abs(diffMinutes) <= 2) {
                                                                // ⏱️ Thỏa điều kiện thời gian ±2 phút
                                                                // tiếp tục xử lý tạo file path...
                                                                trainNumber = Integer.parseInt(trainName);
                                                            }
                                                        } catch (NumberFormatException e) {
                                                            // If trainName is not numeric, fallback to 0 or handle as needed
                                                            trainNumber = 0;
                                                        }
                                                        String folderName =  String.join("_", new String[] { "log", data1.getDate(), data1.getTime(), format(trainNumber, 5), "00" + data1.getControllerRaw() });
                                                        return String.join("/", pathSource, trainName, folderName, pathParent, fileName);
                                                    } catch (Exception e) {
                                                        // TODO: handle exception
                                                        return "";
                                                    }
                                            } 
                                        }
                                    }
        return "";
    }
	public static String format(int input, int digits) {
		if(digits <= 0) {
			return "";
		}
		if ((input < 0) || (String.valueOf(input).length() > digits)) {
			return String.format("%0" + digits + "d", 0);
		}
		return String.format("%0" + digits + "d", input);
	}
    public static String getDateNow() {
                // Lấy ngày hôm nay
        LocalDate today = LocalDate.now();

        // Định dạng yyyy-MM-dd
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String dateStr = today.format(formatter);

        // Ghép prefix
        String result = "日付: " + dateStr;

        System.out.println(result); // Ví dụ: 日付: 2025-05-21
        return result;
    }
    public static String adjustDateLine(String input, String mode) {
        System.out.println("Input: " + input);
        System.out.println("Mode: " + mode);
        // Giả định input có định dạng: "日付: yyyy-MM-dd"
        String[] parts = input.split(": ");
        if (parts.length != 2) return input; // không đúng định dạng thì trả lại nguyên

        String prefix = parts[0]; // "日付"
        String dateStr = parts[1]; // "2025-05-28"

        // Parse thành LocalDate
        LocalDate date = LocalDate.parse(dateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        // Cộng hoặc trừ
        if ("add".equals(mode)) {
            date = date.plusDays(1);
        } else if ("subtract".equals(mode)) {
            date = date.minusDays(1);
        }

        // Định dạng lại
        String result = prefix + ": " + date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        System.out.println(result); // Ví dụ: 日付: 2025-05-29 hoặc 日付: 2025-05-27
        return result;
    }

    public static void updateTimeUI(AppFrame f, AppFrameData appFrameData, AppFrameData data) {
                  System.err.println("RUN button clicked, updating train names.");
                  f.addTimesRunEvent(() -> {
                      List<String> list = SharedUtils.getTimeList(appFrameData.getControllerInfoMap(),
                                                          appFrameData.getChooseTrainName(),
                                                           appFrameData.getDate().replace("-", ""),
                                                            "1");
                      if(list == null || list.isEmpty()) {
                        f.updateTime(new ArrayList<>());
                        System.err.println("No time data found for the selected train.");
                        f.setButtonText("該当ログがありません。日付・車両番号を変更してください。");
                        return;
                      }
                      for(String value : list)
                      {
                          System.out.println("Time: " + value);
                      }
                      if(appFrameData.getTime().equals(""))appFrameData.setTime(list.get(0));  
                      System.err.println("Update procedure finished, updating UI with train time."+data.getTime());
                      f.updateTime(list);
                      f.setButtonText("実行");
                  });    
                  f.setButtonText("実行");
                  f.updateTrainName(data.getTrainNames());
                  f.runTimesRunEvent();       
    }
    public static void updateTableUI(UpdateProcedure updateProcedure, AppFrame f, AppFrameData appFrameData) {
        new Thread(() -> {
            System.err.println("RUN " + updateProcedure.status);
            if (updateProcedure.status == UpdateJobs.Status.DONE) {
                System.err.println("Update procedure is done, now creating logs.");
                f.setButtonText("実行中。。。");
                System.err.println(appFrameData.print());

                // In toàn bộ dữ liệu train
                System.out.println("Result:");
                for (Map.Entry<String, Set<ControllerInfo>> entry : appFrameData.getControllerInfoMap().entrySet()) {
                    String trainName = entry.getKey();
                    Set<ControllerInfo> dataSet = entry.getValue();
                    System.out.println("Train Name: " + trainName);
                    for (ControllerInfo data1 : dataSet) {
                        System.out.println(data1.print());
                    }
                }

                // Train Type xử lý
                String trainType = appFrameData.getTrainType();
                String date = appFrameData.getDate().replace("-", "");
                String trainName = appFrameData.getChooseTrainName();
                String time = appFrameData.getTime();
                Map<String, Set<ControllerInfo>> infoMap = appFrameData.getControllerInfoMap();

                // Loop từ controller 1 → 4
                for (int i = 1; i <= 4; i++) {
                    // Nếu là 単車 và i > 2 → bỏ qua
                    if (trainType.equals("単車") && i > 2) {
                        f.updateUIController(i, new ArrayList<>()); // clear UI
                        continue;
                    }

                    String controllerId = String.valueOf(i);
                    String pathName = SharedUtils.createFileName(infoMap, trainName, time, date, controllerId);
                    System.out.println("Log File Name: " + pathName);

                    LogCreator logCreator = new LogCreator(pathName);
                    List<StationError> controllerLogs = logCreator.create();
                    f.updateUIController(i, controllerLogs); // dùng method tổng quát
                }

                f.setButtonText("実行");
            } else {
                System.err.println("Update procedure is not done yet, please wait.");
            }
        }).start();
    }

}