#include <jni.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h> 

JNIEXPORT jlong JNICALL Java_NativeLibrary_allocate(JNIEnv *env, jclass cls) {
    void* ptr = malloc(1024); // giả sử cần 1KB
    printf("🔧 native malloc: %p\n", ptr);
    return (jlong)(intptr_t)ptr;
}

JNIEXPORT void JNICALL Java_NativeLibrary_free(JNIEnv *env, jclass cls, jlong ptr) {
    void* realPtr = (void*)(intptr_t)ptr;
    free(realPtr);
    printf("❌ native free: %p\n", realPtr);
}
