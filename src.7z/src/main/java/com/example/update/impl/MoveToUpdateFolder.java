package com.example.update.impl;
import com.example.data.ControllerInfo;

import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Set;
import java.util.*;


public class MoveToUpdateFolder extends UpdateJobs {
    Map<String, Set<ControllerInfo>> m = new HashMap<>();
    public Map<String, Set<ControllerInfo>> getControllerInfo() {
        return m;
    }

    public MoveToUpdateFolder(String line) {
        super(line);
    }
    @Override
    protected void doRun() {
        Path sourceRoot = Paths.get(line);   // thư mục chứa các thư mục như 1156, 3704,...
        //Path sourceRoot = Paths.get("path");
        Path targetRoot = Paths.get("input");
        Set<String> skipNames = Set.of("確認済み", "済み");

        try {
            List<Path> folderList = Files.list(sourceRoot)
                                         .filter(Files::isDirectory)
                                         .collect(Collectors.toList());


            for (Path folder : folderList) {
                String folderName = folder.getFileName().toString();             


                try (Stream<Path> stream = Files.walk(folder)) {
                    List<Path> tarFiles = stream
                        .filter(Files::isRegularFile)
                        .filter(p -> !p.toString().endsWith(".xlsx"))
                        .filter(p -> {
                            Path parent = p.getParent();
                            Path grandParent = parent != null ? parent.getParent() : null;

                            return !(skipNames.contains(p.getFileName().toString())
                                  || (parent != null && skipNames.contains(parent.getFileName().toString()))
                                  || (grandParent != null && skipNames.contains(grandParent.getFileName().toString())));
                        })
                        .collect(Collectors.toList());

                    for (Path file : tarFiles) {
                        analyzeData(m, file.getParent().getParent().getFileName().toString());

                        // Lấy đường dẫn tương đối từ thư mục gốc folder
                        Path relativePath = folder.relativize(file);
                        Path targetFolder = targetRoot.resolve(folderName).resolve(relativePath.getParent() != null ? relativePath.getParent() : Paths.get(""));
                        Files.createDirectories(targetFolder);
                        Path target = targetFolder.resolve(file.getFileName());

                        Files.copy(file, target, StandardCopyOption.REPLACE_EXISTING);
                        System.out.println("Copied: " + file + " → " + target);
                    }

                } catch (IOException e) {
                    System.err.println("Exception when move: " + folder + " → " + e.getMessage());
                }
            }

        } catch (IOException e) {
            System.err.println("Main Error: " + e.getMessage());
        }
         finally {
            // In ra kết quả
            // System.out.println("Result:");
            // for (Map.Entry<String, Set<ControllerInfo>> entry : m.entrySet()) {
            //     String trainName = entry.getKey();
            //     Set<ControllerInfo> dataSet = entry.getValue();
            //     System.out.println("Train Name: " + trainName);
            //     for (ControllerInfo data : dataSet) {
            //         System.out.println(data.print());
            //     }
            // }
        }
        setStatus(Status.DONE);
    }
    void analyzeData(Map<String, Set<ControllerInfo>> m, String filename) {
            ControllerInfo data = new ControllerInfo();
            String[] parts = filename.split("_");
            if (parts.length != 5) {
                System.out.println("Uncorrect file name format: " + filename);
                System.out.println("Expected format: <prefix>_<date>_<time>_<trainRaw>_<controllerRaw>");
                return;
            }

            String date = parts[1];         // "20250527"
            String time = parts[2];         // "060750"
            String trainRaw = parts[3];     // "00811"
            String controllerRaw = parts[4]; // "001"

            int hour = Integer.parseInt(time.substring(0, 2));   // 06
            data.setDate(date);
            data.setTime(time);
            data.setHour(String.valueOf(hour)); // "06"
            int minute = Integer.parseInt(time.substring(2, 4)); // 07
            data.setMinute(String.valueOf(minute)); // "07"

            String trainName = String.valueOf(Integer.parseInt(trainRaw));         // 811
            String controllerId = String.valueOf(Integer.parseInt(controllerRaw)); // 1
            data.setControllerRaw(controllerId);

            // ✅ In ra
            System.out.println("Date: " + date);
            System.out.println("Hour: " + hour + " h");
            System.out.println("Minute: " + minute + " m");
            System.out.println("Train Name: " + trainName);
            System.out.println("Controller ID: " + controllerId);
            m.computeIfAbsent(trainName, k -> new HashSet<>()).add(data);
            m.get(trainName).add(data);

    }
}