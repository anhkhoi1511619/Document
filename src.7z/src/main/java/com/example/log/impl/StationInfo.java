package com.example.log.impl;
import com.example.data.*;
import java.util.regex.*;

public class StationInfo extends Jobs {
    public StationInfo(String line, StationError se) {
        super(line, se);
    }
    @Override
    protected void doRun() {
        // Cách 1: tách theo dòng
        String[] lines = line.split("\n"); // \\R: tương thích mọi hệ newline (\n, \r\n)
        if (lines.length > 0) {
            String firstLine = lines[0];
            System.out.println("Dòng đầu tiên:");
            System.out.println(firstLine);
            // Regex để lấy 3 nhóm: số, số, tên
            // Biểu thức chính quy để bắt 3 nhóm
            Pattern pattern = Pattern.compile(
                "(\\d{2}:\\d{2}:\\d{2}\\.\\d+),ROUTE_DATA.*?setStopSequence\\((\\d+)\\).*?ticket number: (\\d+) sequence name: \\[[^\\]]+\\]([^\\s]+)"
            );
            Matcher matcher = pattern.matcher(firstLine);

            if (matcher.find()) {
                String time = matcher.group(1);            // 06:27:03.879
                int stopSequence = Integer.parseInt(matcher.group(2));  // 2
                int ticketNumber = Integer.parseInt(matcher.group(3));  // 18
                String sequenceName = matcher.group(4);    // 高須

                System.out.println("Time: " + time);
                System.out.println("Stop Sequence: " + stopSequence);
                System.out.println("Ticket Number: " + ticketNumber);
                System.out.println("Sequence Name: " + sequenceName);
                this.se.setArrivalTime(time);
                this.se.setStationName(sequenceName);
                this.se.setStationID(stopSequence);
            } else {
                System.out.println("Không khớp định dạng chuỗi.");
            }
        } else {
            System.out.println("no found");
        }
        setStatus(Status.DONE);
    }
    
}
