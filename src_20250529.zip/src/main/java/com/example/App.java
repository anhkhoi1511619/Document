package com.example;
import com.example.utils.SharedUtils;
import com.example.data.StationError;
import com.example.base.AppFrame;
import com.example.data.AppFrameData;
import com.example.data.ControllerInfo;
import com.example.log.LogCreator;
import com.example.update.impl.*;

import javax.swing.*;
import java.util.List;
import java.util.ArrayList;
import com.example.data.ControllerInfo;

import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Set;
import java.util.*;

public class App {
    public static void main(String[] args) throws Exception {
      System.err.println("Check Error Tool");
      SwingUtilities.invokeLater(() -> {
        AppFrameData appFrameData = new AppFrameData();
	      AppFrame f = new AppFrame(appFrameData);
        UpdateProcedure updateProcedure = new UpdateProcedure("\\\\lecip_dc2\\LCP\\H-▼LCP品質保証本部\\H 【LCP品証 各部データ受渡専用】\\202505\\広島電鉄\\20250422_広電電車_582_1156（対策ソフトの先行展開結果確認）");
        updateProcedure.run();
        updateProcedure.updateRunButton(appFrameData, (data) -> {
                  System.err.println("RUN button clicked, updating train names.");
                  f.addTimesRunEvent(() -> {
                      List<String> list = SharedUtils.getTimeList(appFrameData.getControllerInfoMap(),
                                                          appFrameData.getChooseTrainName(),
                                                           appFrameData.getDate().replace("-", ""),
                                                            "1");
                      if(list == null || list.isEmpty()) {
                        f.updateTime(new ArrayList<>());
                        System.err.println("No time data found for the selected train.");
                        f.setButtonText("実行");
                        return;
                      }
                      for(String value : list)
                      {
                          System.out.println("Time: " + value);
                      }
                      if(appFrameData.getTime().equals(""))appFrameData.setTime(list.get(0));  
                      System.err.println("Update procedure finished, updating UI with train time."+data.getTime());
                      f.updateTime(list);
                  });    
                  f.setButtonText("実行");
                  f.updateTrainName(data.getTrainNames());
                  f.runTimesRunEvent();
              });
        f.setRunEvent((actionEvent) -> {
            new Thread(() -> {
                  System.err.println("RUN "+ updateProcedure.status);
                  if(updateProcedure.status == UpdateJobs.Status.DONE) {
                      System.err.println("Update procedure is done, now creating logs.");
                      f.setButtonText("実行中。。。");
                      System.err.println(appFrameData.print());
                      System.out.println("Result:");
                      for (Map.Entry<String, Set<ControllerInfo>> entry : appFrameData.getControllerInfoMap().entrySet()) {
                          String trainName = entry.getKey();
                          Set<ControllerInfo> dataSet = entry.getValue();
                          System.out.println("Train Name: " + trainName);
                          for (ControllerInfo data1 : dataSet) {
                              System.out.println(data1.print());
                          }
                      }
                      System.err.println(appFrameData.print());
                      String pathName =  SharedUtils.createFileName(appFrameData.getControllerInfoMap(),
                                                          appFrameData.getChooseTrainName(),
                                                           appFrameData.getTime(),
                                                           appFrameData.getDate().replace("-", ""),
                                                            "1");
                      System.out.println("Log File Name: " + pathName);
                      LogCreator logCreator1 = new LogCreator(pathName);
                      List<StationError> controller1Logs = logCreator1.create();
                      f.updateUIController1(controller1Logs);
                      pathName =  SharedUtils.createFileName(appFrameData.getControllerInfoMap(),
                                                          appFrameData.getChooseTrainName(),
                                                           appFrameData.getTime(),
                                                           appFrameData.getDate().replace("-", ""),
                                                            "2");
                      System.out.println("Log File Name: " + pathName);
                      LogCreator logCreator2 = new LogCreator(pathName);
                      List<StationError> controller2Logs = logCreator2.create();
                      f.updateUIController2(controller2Logs);
                      if(appFrameData.getTrainType().equals("単車")) {
                        System.err.println("Train Type is single, no controller 3 logs.");
                        f.updateUIController3(new ArrayList<>());
                        f.updateUIController4(new ArrayList<>());
                        f.setButtonText("実行");
                        return;
                      } else if(appFrameData.getTrainType().equals("連結車両")) {
                        System.err.println("Train Type is linked, creating controller 3 logs.");
                      }
                      pathName =  SharedUtils.createFileName(appFrameData.getControllerInfoMap(),
                                                          appFrameData.getChooseTrainName(),
                                                           appFrameData.getTime(),
                                                           appFrameData.getDate().replace("-", ""),
                                                            "3");
                      System.out.println("Log File Name: " + pathName);
                      LogCreator logCreator3 = new LogCreator(pathName);
                      List<StationError> controller3Logs = logCreator3.create();
                      f.updateUIController3(controller3Logs);
                      pathName =  SharedUtils.createFileName(appFrameData.getControllerInfoMap(),
                                                          appFrameData.getChooseTrainName(),
                                                           appFrameData.getTime(),
                                                           appFrameData.getDate().replace("-", ""),
                                                            "4");
                      System.out.println("Log File Name: " + pathName);
                      LogCreator logCreator4 = new LogCreator(pathName);
                      List<StationError> controller4Logs = logCreator4.create();
                      f.updateUIController4(controller4Logs);
                      f.setButtonText("実行");
                  } else {
                      System.err.println("Update procedure is not done yet, please wait.");
                  }
            }).start();

            });
      });
    }

}
