package com.example;
import com.example.data.StationError;
import com.example.base.AppFrame;
import com.example.data.AppFrameData;
import com.example.data.ControllerInfo;
import com.example.log.LogCreator;
import com.example.update.impl.*;

import javax.swing.*;
import java.util.List;
import java.util.ArrayList;
import com.example.data.ControllerInfo;

import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Set;
import java.util.*;

public class App {
    public static void main(String[] args) throws Exception {
      System.err.println("Check Error Tool");
      SwingUtilities.invokeLater(() -> {
        AppFrameData appFrameData = new AppFrameData();
	      AppFrame f = new AppFrame(appFrameData);
        UpdateProcedure updateProcedure = new UpdateProcedure("server");
        updateProcedure.run();
        updateProcedure.updateRunButton(appFrameData, (data) -> {
                  f.updateTrainName(data.getTrainNames());
                  f.setButtonText("実行");
              });
        f.setRunEvent((actionEvent) -> {
                  System.err.println("RUN "+ updateProcedure.status);
                  if(updateProcedure.status == UpdateJobs.Status.DONE) {
                      System.err.println("Update procedure is done, now creating logs.");
                      f.setButtonText("実行中。。。");
                      System.err.println(appFrameData.print());
                      System.out.println("Result:");
                      for (Map.Entry<String, Set<ControllerInfo>> entry : appFrameData.getControllerInfoMap().entrySet()) {
                          String trainName = entry.getKey();
                          Set<ControllerInfo> dataSet = entry.getValue();
                          System.out.println("Train Name: " + trainName);
                          for (ControllerInfo data1 : dataSet) {
                              System.out.println(data1.print());
                          }
                      }
                      List<String> list = getTimeList(appFrameData.getControllerInfoMap(),
                                                          appFrameData.getChooseTrainName(),
                                                           //appFrameData.getDate().replace("-", ""),
                                                           "20250527",
                                                            "1");
                      //if(list == null || list.isEmpty()) return;
                      appFrameData.setTime(list.get(0));                                        
                      for(String value : list)
                      {
                          System.out.println("Time: " + value);
                      }
                      System.err.println(appFrameData.print());
                      String pathName =  createFileName(appFrameData.getControllerInfoMap(),
                                                          appFrameData.getChooseTrainName(),
                                                           appFrameData.getTime(),
                                                           "20250527",
                                                            "1");
                      System.out.println("Log File Name: " + pathName);
                      LogCreator logCreator1 = new LogCreator(pathName);
                      List<StationError> controller1Logs = logCreator1.create();
                      f.updateUIController1(controller1Logs);
                      // LogCreator logCreator2 = new LogCreator("./operation_log2.csv");
                      // List<StationError> controller2Logs = logCreator2.create();
                      // f.updateUIController2(controller2Logs);
                      // LogCreator logCreator3 = new LogCreator("./operation_log3.csv");
                      // List<StationError> controller3Logs = logCreator3.create();
                      // f.updateUIController3(controller3Logs);
                      // LogCreator logCreator4 = new LogCreator("./operation_log4.csv");
                      // List<StationError> controller4Logs = logCreator4.create();
                      // f.updateUIController4(controller4Logs);
                      f.setButtonText("実行");
                  } else {
                      System.err.println("Update procedure is not done yet, please wait.");
                  }
              });
      });
    }
    static List<String> getTimeList(Map<String, Set<ControllerInfo>> controllerInfoMap,String trainName, String date, String id)
    {
        List<String> list = new ArrayList();
        if(controllerInfoMap == null) return list;
                      for (Map.Entry<String, Set<ControllerInfo>> entry : controllerInfoMap.entrySet()) {
                          String trainNameStr = entry.getKey();
                          if(!trainNameStr.equals(trainName)) continue;
                          Set<ControllerInfo> dataSet = entry.getValue();
                          System.out.println("Train Name: " + trainNameStr);
                          for (ControllerInfo data1 : dataSet) {
                              System.out.println(data1.print());
                              if (data1.getControllerRaw().equals(id) && 
                                    data1.getDate().equals(date))
                              {
                                    list.add(data1.getTime());
                              }
                          }
                      }
                      return list;
    }
    static String createFileName(Map<String, Set<ControllerInfo>> controllerInfoMap,String trainName, String time, String date, String id)
    {
        System.out.println("Train Name: " + trainName);
        System.out.println("time: " + time.substring(0, 4));
        System.out.println("date: " + date);
        System.out.println("Train id: " + id);

        final String pathSource = "input";
        final String pathParent = "log";
        final String fileName = "operation_log.csv";
        if(controllerInfoMap == null) return "";
                      for (Map.Entry<String, Set<ControllerInfo>> entry : controllerInfoMap.entrySet()) {
                          String trainNameStr = entry.getKey();
                          if(!trainNameStr.equals(trainName)) continue;
                          Set<ControllerInfo> dataSet = entry.getValue();
                          System.out.println("Train Name: " + trainNameStr);
                          for (ControllerInfo data1 : dataSet) {
                              System.out.println(data1.print());
                              System.out.println("time check: " + data1.getTime().substring(0, 4));
                              System.out.println("date check: " + data1.getDate());
                              System.out.println("Train id check: " + data1.getControllerRaw());
                              if (data1.getControllerRaw().equals(id) && 
                                    data1.getDate().equals(date) &&
                                        data1.getTime().substring(0, 4).equals(time.substring(0, 4)))
                              {
                                    System.out.println("Da vao day");
                                    String folderName =  String.join("_", "log", data1.getDate(), data1.getTime(), "00"+trainName, "00"+data1.getControllerRaw());
                                    return String.join("/", pathSource, trainName, folderName, pathParent, fileName);
                              } 
                          }
                      }
        return "";
    }
}
