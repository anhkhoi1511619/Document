package com.example.data;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ControllerInfo {
        public String date;         // "20250527"
        public String time;         // "060750"
        public String hour;         // "060750"
        public String minute;       // "060750"
        public String second;       // "060750"
        //String trainRaw;     // "00811"
        public String controllerRaw; // "001"
        //Map<String, Data> map; // "00811"
        public String getHour() {
            return hour;
        }
        public void setHour(String hour) {
            this.hour = hour;
        }
        public String getSecond() {
            return second;
        }
        public void setSecond(String second) {
            this.second = second;
        }
        public String getMinute() {
            return minute;
        }
        public void setMinute(String minute) {
            this.minute = minute;
        }
        public String getDate() {
            return date;
        }
        public void setDate(String date) {
            this.date = date;
        }
        public String getTime() {
            return time;
        }
        
        public void setTime(String time) {
            this.time = time;
        }
    public String print() {
        StringBuilder ret = new StringBuilder();
        for (var field : this.getClass().getFields()) {
            try {
                var val = field.get(this);
                var valStr = val != null ? val.toString() : "null";
                ret.append(field.getName()).append(": ").append(valStr).append(",");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return ret.toString();
    }

        // public String getTrainRaw() {
        //     return trainRaw;
        // }
        // public void setTrainRaw(String trainRaw) {
        //     this.trainRaw = trainRaw;
        // }
        public String getControllerRaw() {
            return controllerRaw;
        }
        public void setControllerRaw(String controllerRaw) {
            this.controllerRaw = controllerRaw;
        }

        // public static void analyzeData(Map<String, Set<Data>> m, String filename) {
        //     Data data = new Data();
        //     String[] parts = filename.split("_");
        //     if (parts.length != 5) {
        //         System.out.println("Tên file không đúng định dạng");
        //         return;
        //     }

        //     String date = parts[1];         // "20250527"
        //     String time = parts[2];         // "060750"
        //     String trainRaw = parts[3];     // "00811"
        //     String controllerRaw = parts[4]; // "001"

        //     int hour = Integer.parseInt(time.substring(0, 2));   // 06
        //     data.setDate(date);
        //     data.setTime(time);
        //     data.setHour(String.valueOf(hour)); // "06"
        //     int minute = Integer.parseInt(time.substring(2, 4)); // 07
        //     data.setMinute(String.valueOf(minute)); // "07"

        //     String trainName = String.valueOf(Integer.parseInt(trainRaw));         // 811
        //     String controllerId = String.valueOf(Integer.parseInt(controllerRaw)); // 1
        //     data.setControllerRaw(controllerId);

        //     // ✅ In ra
        //     System.out.println("Ngày: " + date);
        //     System.out.println("Giờ: " + hour + " giờ");
        //     System.out.println("Phút: " + minute + " phút");
        //     System.out.println("Tên tàu: " + trainName);
        //     System.out.println("Controller ID: " + controllerId);
        //     m.computeIfAbsent(trainName, k -> new HashSet<>()).add(data);
        //     m.get(trainName).add(data);

        // }
}