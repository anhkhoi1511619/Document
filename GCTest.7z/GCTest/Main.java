public class Main {
    public static void main(String[] args) throws InterruptedException {
        {
            NativeResource res = new NativeResource();
            System.out.println("📝 NativeResource is currently alive...");
        }

        System.out.println("🗑  Setting res = null and invoking GC...");
        for (int i = 0; i < 3; i++) {
            System.gc();
            Thread.sleep(1000);
        }

        //System.gc();

        //Thread.sleep(2000); // chờ để cleaner thread dọn
    }
}
